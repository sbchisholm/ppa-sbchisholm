============================================================================
STLSoft - README

; Created:  29th March 2002
; Updated:  19th November 2007

============================================================================

For information on this release, please refer to the CHANGES.txt release
notes included in the distribution.

For general information and enquiries on STLSoft, please
visit the STLSoft newsgroup at:

  news://news.digitalmars.com/c++.stlsoft

----------------------------------------------------------------------------
END OF FILE
----------------------------------------------------------------------------
